package com.larntech.aliesa.main;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.larntech.aliesa.R;
import com.larntech.aliesa.login.LoginActivity;
import com.larntech.aliesa.map.MapsActivity;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showLogin();
    }

    private void showLogin(){
        new Handler().postDelayed(this::checkSession,1500);
    }

    private void checkSession(){
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent(MainActivity.this, MapsActivity.class));
        }else{
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        }
        finish();
    }
}